const express = require('express'); // import express framework (web server)
const { MongoClient } = require('mongodb'); // Import the module mongodb
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;
app.use(bodyParser.json());

const uri = 'mongodb://localhost:27017'; // Define connection string
const client = new MongoClient(uri); // Create the MongoClient instance
const dbName = 'bloggingAPI'; // Naming it

const main = async () => { // Establish a connection to the database using the MongoClient instance
    try {
        await client.connect();
        console.log('Connected to MongoDB ...');
        const db = client.db(dbName); // from MongoDB native driver, select a database 'dbName'
        const postsCollection = db.collection('posts'); // from MongoDB native driver, select a collection 'posts' within the 
                                                        // database. 'postsCollection' performs operations on the 'posts' collection.

        // POST - /posts - an endpoint to add a new blog post with a title, content, and username
        app.post('/posts', async (req, res) => {
            try {
                // Check if  request body is an array. If so, insert all of the inputted elements
                if (Array.isArray(req.body)) {
                    const result = await postsCollection.insertMany(req.body); // if inserted array of documents rather than only an object
                    res.status(201).json(result);
                } else {
                    // If it's not an array, insert a single document
                    const result = await postsCollection.insertOne(req.body); // Else, if inserted an object rather than an array
                    res.status(201).json(result);
                }
            } catch (err) {
                res.status(500).json({ message: err.message });
            }
        });


        // GET - /posts - an endpoint to retrieve all blog posts.
        app.get('/posts', async (req, res) => {
            try {
                const posts = await postsCollection.find({}).toArray(); // using find() method to query a collection for documents
                res.json(posts);
            } catch (err) {
                res.status(500).send("Failed to fetch posts.");
            }
        });

        // GET - /posts/user/:userName - an endpoint to retrieve all blog posts by a given username.
        app.get('/posts/user/:userName', async (req, res) => {
            try {
                const posts = await postsCollection.find({ userName: req.params.userName }).toArray();
                res.json(posts);
            } catch (err) {
                res.status(500).send("Failed to fetch posts.");
            }
        });

        // GET - /posts/title/:searchWord - an endpoint to retrieve all blog posts by containing a given word (searchWord) in the title.
        app.get('/posts/title/:searchWord', async (req, res) => {
            try {
                const posts = await postsCollection.find({ title: { $regex: req.params.searchWord} }).toArray(); // '$regex' MongoDB operator used to specifiy regular expression pattern for matching.
                                                                                                // optional: '$options' specifies that regex should be case-insentitive.
                res.json(posts);
            } catch (err) {
                res.status(500).send("Failed to fetch posts.");
            }
        });

        // GET - /posts/content/:searchWord - an endpoint to retrieve all blog posts containing a given word in the content.
        app.get('/posts/content/:searchWord', async (req, res) => {
            try {
                const posts = await postsCollection.find({ content: { $regex: req.params.searchWord} }).toArray();
                res.json(posts);
            } catch (err) {
                res.status(500).send("Failed to fetch posts.");
            }
        });

        // DELETE - /posts/user/:userName - an endpoint to delete all blogs by a given username.
        app.delete('/posts/user/:userName', async (req, res) => {
            try {
                const result = await postsCollection.deleteMany({ userName: req.params.userName }); // 'deleteMany' delete all blog posts with a specific user.
                res.json({ message: `Deleted ${result.deletedCount} posts.` });
            } catch (err) {
                res.status(500).send("Failed to delete posts.");
            }
        });

        // DELETE - /posts/content/:searchWord - an endpoint to delete all blogs that contain a certain word (searchWord).
        app.delete('/posts/content/:searchWord', async (req, res) => {
            try {
                const result = await postsCollection.deleteMany({ content: { $regex: req.params.searchWord} });
                res.json({ message: `Deleted ${result.deletedCount} posts.` });
            } catch (err) {
                res.status(500).send("Failed to delete posts.");
            }
        });

        // GET - /posts/count/:userName - an endpoint that returns the userName and the number of blogs posted by a userName
        app.get('/posts/count/:userName', async (req, res) => {
            try {
                const count = await postsCollection.countDocuments({ userName: req.params.userName });
                res.json({ userName: req.params.userName, postCount: count });
            } catch (err) {
                res.status(500).send("Failed to fetch post count.");
            }
        });

        app.listen(PORT, () => {
            console.log(`Server is running on port ${PORT}`);
        });
    } catch (error) {
        console.error(error);
    }
};

main().catch((err) => console.log(err));